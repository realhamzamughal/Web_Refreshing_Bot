import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Main{
    private static int iteration = 0;

    public static void main(String[] args) throws IOException, InterruptedException {
        String url = "https://www.ft.com/"; // replace with the URL you want to refresh
        String initialContent = getWebPageContent(url);
        while (true) {
            Thread.sleep(new Random().nextInt(4000) + 3000); // sleep for 3 to 6 seconds
            iteration++;
            System.out.println("Iteration: " + iteration);
            String newContent = getWebPageContent(url);
            if (!newContent.equals(initialContent)) {
                System.out.println("Content has changed!");
                beep();
                initialContent = newContent;
            } else {
                System.out.println("No change detected.");
            }
        }
    }

    private static String getWebPageContent(String url) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        int responseCode = con.getResponseCode();
        if (responseCode == 200) {
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } else {
            return "";
        }
    }

    private static void beep() {
        try {
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(Main.class.getResource("/beep.wav")));
            clip.start();
        } catch (Exception e) {
            System.err.println("Beep sound error: " + e.getMessage());
        }
    }
}
